import { system } from "@minecraft/server";
import { CFG, PT_POOL } from "../config.js";
import { dpGet, dpSet, getPlayerReg, setPlayerReg } from "./storage.js";
import { getGem } from "./scoreboard.js";

// [FIX C-1] BigInt bitmask — aman untuk PT_POOL berapa pun jumlahnya.
// JS bitwise (|, <<) hanya 32-bit; BigInt tidak ada batasnya.
// Backward compatible: base-36 lama (< 31 item) tetap terbaca benar.

function b36toBigInt(str) {
  let result = 0n;
  for (const c of (str || "0").toLowerCase()) {
    const d = c <= "9" ? c.charCodeAt(0) - 48 : c.charCodeAt(0) - 87;
    result = result * 36n + BigInt(d);
  }
  return result;
}

export const ptToBitmask = tags => {
  let m = 0n;
  PT_POOL.forEach((p, i) => { if (tags.includes(p.tag)) m |= (1n << BigInt(i)); });
  return m.toString(36);
};

export const bitmaskToPt = str => {
  try {
    if (!str || str === "0") return [];
    const m = b36toBigInt(str);
    return PT_POOL.filter((_, i) => (m >> BigInt(i)) & 1n);
  } catch { return []; }
};

export const playerPtMask = player =>
  ptToBitmask(PT_POOL.filter(p => player.hasTag(p.tag)).map(p => p.tag));

// [TPS] Debounce syncPlayerData: skip jika < 20 tick lalu untuk player yang sama.
const _syncCooldown = new Map();

export function syncPlayerData(player) {
  try {
    const now = system.currentTick;
    if ((now - (_syncCooldown.get(player.id) ?? -999)) < 20) return;
    _syncCooldown.set(player.id, now);
    const reg = getPlayerReg();
    const ptTags = PT_POOL.filter(p => player.hasTag(p.tag)).map(p => p.tag);
    reg[player.id] = { name: player.name, gem: getGem(player), ptm: ptToBitmask(ptTags) };
    setPlayerReg(reg);
    dpSet(CFG.K_PT_DATA + player.id, ptTags);
  } catch (e) { console.warn("[Gacha] syncPlayerData:", e); }
}

// Bypass debounce — untuk admin import, logout, buildBulkExport
export function syncPlayerDataForce(player) {
  _syncCooldown.delete(player.id);
  syncPlayerData(player);
}

// Batch update registry untuk beberapa player sekaligus (satu read + satu write)
// Dipakai oleh buildBulkExport untuk efisiensi TPS
export function batchSyncToRegistry(players) {
  try {
    const reg = getPlayerReg();
    for (const player of players) {
      const ptTags = PT_POOL.filter(p => player.hasTag(p.tag)).map(p => p.tag);
      reg[player.id] = { name: player.name, gem: getGem(player), ptm: ptToBitmask(ptTags) };
      dpSet(CFG.K_PT_DATA + player.id, ptTags);
      _syncCooldown.set(player.id, system.currentTick);
    }
    if (players.length) setPlayerReg(reg);
  } catch (e) { console.warn("[Gacha] batchSyncToRegistry:", e); }
}
